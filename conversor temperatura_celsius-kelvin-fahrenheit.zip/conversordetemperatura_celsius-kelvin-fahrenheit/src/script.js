
//De Celsius para Fahrenheit e vice-versa//
var tcelsius = parseFloat( prompt("Temperatura em graus Celsius: ") );
var tfahrenheit = (9*tcelsius/5) + 32 ;

alert("Temperatura em graus Fahrenheit é de : " + tfahrenheit.toFixed(2));

var tfahrenheit = parseFloat( prompt("Temperatura em graus Fahrenheit: ") );
var tcelsius = 5*(tfahrenheit -32) / 9;
    
alert("Temperatura em graus Celsius é de : " + tcelsius.toFixed(2));

//Fahrenheit, Celsius para Kelvin //

var tfahrenheit = parseFloat( prompt("Temperatura em Fahrenheit: ") );
var tkelvin = 5*(tfahrenheit -32) / 9 + 273;
    
alert("Temperatura em graus Kelvin é de : " + tkelvin.toFixed(2));
