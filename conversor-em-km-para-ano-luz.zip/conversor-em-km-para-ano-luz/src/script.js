var valorAnosLuz = prompt(
  "Qual valor em Anos-Luz você quer converter para quilômetros?"
);

parseFloat(valorAnosLuz);

var valorEmKm = valorAnosLuz * 9500000000000;

alert(valorEmKm);
