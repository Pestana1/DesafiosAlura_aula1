//Exemplo da aula01//
var moedaValor = 50;
var cotacaoDolar = 5.09;
var resultadoEmReal = moedaValor * cotacaoDolar;
resultadoEmReal = resultadoEmReal.toFixed(2);

//Desafio das cotações//

var moedaValor = 500.0;
var cotacaoEur = 5.54;
var resultadoEmReal = moedaValor * cotacaoEur;
resultadoEmReal = resultadoEmReal.toFixed();

alert("A cotação do Euro para o Real é :" + resultadoEmReal);

var moedaValor = 500.0;
var valorBitcoin = 116.2;
var resultadoEmReal = moedaValor * valorBitcoin;
resultadoEmReal = resultadoEmReal.toFixed(3);

alert("O valor de Bitcoin em Real é :" + resultadoEmReal);
