# DesafioAlura_ConversorDeMoedas

A Pen created on CodePen.io. Original URL: [https://codepen.io/vafepe/pen/XWBxMWe](https://codepen.io/vafepe/pen/XWBxMWe).

Este conversor, permite colocar o valor e as cotações das moedas que desejar e faz a conversao.